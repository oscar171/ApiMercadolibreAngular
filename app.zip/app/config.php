<?php 
define('APP_ID', '8024250253874834'); 
define('APP_KEY', 'ObEggtw9McujzzJ9jehDuX6ZcPDvonbj'); 

?>